package org.example.java_pro_8.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;

@Entity
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "limits")
public class Limits {

    @Id
    Long id;

    @Column(name = "balance", columnDefinition = "BigDecimal.class")
    BigDecimal balance;

    @Column(name = "user_id")
    Long userId;
}
