package org.example.java_pro_8.controller.exception;

public class LimitIllegalArgumentException extends RuntimeException {
    public LimitIllegalArgumentException(String param) {
        super(param);
    }
}
