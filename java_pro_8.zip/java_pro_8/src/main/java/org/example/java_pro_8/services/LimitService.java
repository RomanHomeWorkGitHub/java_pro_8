package org.example.java_pro_8.services;

import lombok.AccessLevel;
import lombok.RequiredArgsConstructor;
import lombok.experimental.FieldDefaults;
import org.example.java_pro_8.config.LimitProperties;
import org.example.java_pro_8.controller.dto.BalanceDto;
import org.example.java_pro_8.controller.exception.LimitIllegalArgumentException;
import org.example.java_pro_8.dao.LimitRepository;
import org.example.java_pro_8.model.Limits;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.List;

@Service
@RequiredArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
public class LimitService {

    LimitProperties properties;
    LimitRepository limitRepository;

    public Limits getLimitById(Long userId) {
        return limitRepository.findAllByUserId(userId);
    }

    public BalanceDto updateBalanceByUserId(Long userId, BigDecimal amount) {
        boolean existsUserId = limitRepository.existsByUserId(userId);

        if (!existsUserId) {
            limitRepository.save(new Limits(userId, new BigDecimal(properties.getLimit()).subtract(amount), userId));
            return new BalanceDto(limitRepository.findAllByUserId(userId).getBalance());
        }

        Limits limit = limitRepository.findAllByUserId(userId);
        if (limit == null || limit.getBalance() == null) {
            throw new LimitIllegalArgumentException("Что-то пошло не так, операция не возможна, повторите попытку еще раз");
        }

        BigDecimal balance = limit.getBalance();
        if (balance.compareTo(amount) < 0) {
            throw new LimitIllegalArgumentException("Операция не возможна, превышен лимит операций за день");
        }

        limit.setBalance(balance.subtract(amount));
        limitRepository.save(limit);

    return new BalanceDto(limit.getBalance());
    }

    public void resetDailyLimit(BigDecimal balance) {
        List<Limits> list = limitRepository.findAllByOrderById();

        if (list.isEmpty()) {
            throw new LimitIllegalArgumentException("Отсутствуют лимиты для обновления");
        }

        for (Limits limit : list) {
            if (limit.getBalance().compareTo(balance) != 0) {
                limit.setBalance(balance);
                limitRepository.save(limit);
            }
        }
    }
}
