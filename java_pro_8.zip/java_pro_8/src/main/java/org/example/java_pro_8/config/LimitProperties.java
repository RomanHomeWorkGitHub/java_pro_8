package org.example.java_pro_8.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;

import java.math.BigDecimal;

@Data
@ConfigurationProperties(prefix = "scheduler.daily")
public class LimitProperties {
    private String cron;
    private Long limit;
}
