package org.example.java_pro_8.dao;

import org.example.java_pro_8.model.Limit;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;

@Repository
public interface LimitRepository extends JpaRepository<Limit, Long> {

    public Limit findByUserId(Long id);

    public BigDecimal getBalanceByUserId(Long id);

    public void updateBalanceByUserId(Long id, BigDecimal amount);

    public Limit saveLimit(Limit limit);

    @Modifying
    @Query("Update Limit l set l.balance = :amount where l.balance != :amount")
    public void updateAllBalances(@Param("balance") BigDecimal amount);
}
