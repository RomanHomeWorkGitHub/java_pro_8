package org.example.java_pro_8;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JavaPro8Application {

    public static void main(String[] args) {
        SpringApplication.run(JavaPro8Application.class);
    }

}
