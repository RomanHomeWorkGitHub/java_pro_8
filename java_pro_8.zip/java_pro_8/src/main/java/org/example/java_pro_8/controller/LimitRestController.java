package org.example.java_pro_8.controller;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.experimental.FieldDefaults;
import org.example.java_pro_8.controller.dto.BalanceDto;
import org.example.java_pro_8.controller.dto.LimitDto;
import org.example.java_pro_8.services.LimitService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;

@RestController
@AllArgsConstructor
@ResponseStatus(HttpStatus.OK)
@RequestMapping("org/example/")
@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
class LimitRestController {

    LimitService limitService;

    @GetMapping("/{id}/getLimit")
    public ResponseEntity<LimitDto> getLimitById(@PathVariable Long id) {
        return ResponseEntity.ok(new LimitDto(limitService.getLimitById(id)));
    }

    @PostMapping("/{userId}/updateLimit")
    public ResponseEntity<BalanceDto> updateLimitByUserId(@PathVariable Long userId, @RequestParam BigDecimal amount) {
        return ResponseEntity.ok(limitService.updateBalanceByUserId(userId, amount));
    }

    @PostMapping("/{userId}/rollbackLimit")
    public ResponseEntity<BalanceDto> rollbackLimit(@PathVariable Long userId, @RequestParam BigDecimal amount) {
        return ResponseEntity.ok(limitService.rollbackBalanceByUserId(userId, amount));
    }
}
