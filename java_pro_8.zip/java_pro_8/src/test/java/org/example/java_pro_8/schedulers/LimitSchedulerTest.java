package org.example.java_pro_8.schedulers;

import org.example.java_pro_8.config.LimitProperties;
import org.example.java_pro_8.dao.LimitRepository;
import org.example.java_pro_8.model.Limits;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.context.bean.override.mockito.MockitoSpyBean;
import org.springframework.test.context.jdbc.Sql;

import java.math.BigDecimal;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@SpringBootTest
class LimitSchedulerTest {

    @Autowired
    LimitScheduler limitScheduler;

    @MockitoSpyBean
    LimitRepository limitRepository;

    @MockitoBean
    LimitProperties properties;

    @Test
    @Sql(executionPhase = Sql.ExecutionPhase.AFTER_TEST_METHOD,
            statements = "update limits set balance = 10000")
    public void testResetDailyLimit() {
        BigDecimal limit = new BigDecimal(20000L);
        when(properties.getLimit()).thenReturn(20000L);

        limitScheduler.resetLimit();
        Limits limits = limitRepository.findAllByUserId(1L);
        BigDecimal limitActual = limits.getBalance();
        assertEquals(0, limit.compareTo(limitActual));
        verify(limitRepository, times(100)).save(any(Limits.class));
    }
}