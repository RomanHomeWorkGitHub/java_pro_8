package org.example.java_pro_8.schedulers;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.experimental.FieldDefaults;
import org.example.java_pro_8.config.LimitProperties;
import org.example.java_pro_8.services.LimitService;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;

@Component
@AllArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
public class LimitScheduler {

    LimitProperties properties;
    LimitService limitService;

    @Scheduled(cron = "${scheduler.daily.cron}")
    public void limit() {
        limitService.resetDailyLimit(new BigDecimal(properties.getLimit()));
    }
}
