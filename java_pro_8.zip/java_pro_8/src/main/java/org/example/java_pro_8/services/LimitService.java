package org.example.java_pro_8.services;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.experimental.FieldDefaults;
import org.example.java_pro_8.config.LimitProperties;
import org.example.java_pro_8.dao.LimitRepository;
import org.example.java_pro_8.model.Limit;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;

@Service
@AllArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
public class LimitService {

    LimitProperties properties;
    LimitRepository limitRepository;

    public Limit getLimitById(Long userId) {
        return limitRepository.findByUserId(userId);
    }

    public BigDecimal updateBalanceByUserId(Long id, BigDecimal amount) {
        BigDecimal balance = limitRepository.getBalanceByUserId(id);

        if (balance == null) {
            limitRepository.saveLimit(new Limit(id, new BigDecimal(properties.getLimit()).subtract(amount), id));
            return limitRepository.getBalanceByUserId(id);
        }

        if (balance.compareTo(amount) > 0) {
            throw new IllegalArgumentException("Операция не возможна, превышен лимит операций за день");
        }

        balance = balance.subtract(amount);
        limitRepository.updateBalanceByUserId(id, balance);

    return balance;
    }

    public void resetDailyLimit(BigDecimal dailyLimit) {
        limitRepository.updateAllBalances(dailyLimit);
    }
}
