package org.example.java_pro_8.controller;

import org.example.java_pro_8.config.LimitProperties;
import org.example.java_pro_8.dao.LimitRepository;
import org.example.java_pro_8.model.Limits;
import org.example.java_pro_8.services.LimitService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.context.bean.override.mockito.MockitoSpyBean;
import org.springframework.test.context.jdbc.Sql;
import org.springframework.test.web.servlet.MockMvc;

import java.math.BigDecimal;

import static org.hamcrest.Matchers.equalTo;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;
import static org.springframework.http.MediaType.APPLICATION_JSON_UTF8_VALUE;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
class LimitsRestControllerTest {

    Long userId = 1L;

    @Autowired
    MockMvc mockMvc;

    @Autowired
    private LimitService limitService;

    @MockitoSpyBean
    private LimitRepository limitRepository;

    @MockitoBean
    private LimitProperties limitProperties;

    @Test
    void getLimitById_ok() throws Exception {
        mockMvc.perform(get("/org/example/{id}/getLimit", userId))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id","id").value(1))
                .andExpect(jsonPath("$.balance","balance").value(10000))
                .andExpect(jsonPath("$.userId","userId").value(1))
                .andDo(print());
    }

    @Test
    public void testUpdateBalanceByUserId_whenBalanceIsNull() throws Exception {
        when(limitRepository.findAllByUserId(userId)).thenReturn(null);

        mockMvc.perform(post("/org/example/{userId}/updateLimit", userId)
                        .param("amount", String.valueOf(1000)))
                .andExpect(status().isInternalServerError())
                .andExpect(jsonPath("$.statusCode", equalTo(HttpStatus.INTERNAL_SERVER_ERROR.value())))
                .andExpect(jsonPath("$.description")
                        .value("Что-то пошло не так, операция не возможна, повторите попытку еще раз"))
                .andDo(print());
        // проверяем, что метод save был вызван
        verify(limitRepository, times(0)).save(any(Limits.class));
    }

    @Test
    public void testUpdateBalanceByUserId_whenBalanceIsGreaterThanAmount() throws Exception {
        mockMvc.perform(post("/org/example/{userId}/updateLimit", userId)
                        .param("amount", String.valueOf(20000))
                        .contentType(APPLICATION_JSON_UTF8_VALUE))
                .andExpect(status().isInternalServerError())
                .andExpect(jsonPath("$.statusCode", equalTo(HttpStatus.INTERNAL_SERVER_ERROR.value())))
                .andExpect(jsonPath("$.description")
                        .value("Операция не возможна, превышен лимит операций за день"))
                .andDo(print());
        // проверяем, что метод save был вызван
        verify(limitRepository, times(0)).save(any(Limits.class));
    }

    @Test
    @Sql(statements = "update limits set balance = 10000 where user_id = 1", executionPhase = Sql.ExecutionPhase.AFTER_TEST_METHOD)
    public void testUpdateBalanceByUserId_ok() throws Exception {
        mockMvc.perform(post("/org/example/{userId}/updateLimit", userId)
                        .param("amount", String.valueOf(1000))
                        .contentType(APPLICATION_JSON_UTF8_VALUE))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.balance", equalTo(9000)))
                .andDo(print()).andReturn();
    }

    @Test
    public void testRollbackBalanceByUserId_whenBalanceIsNull() throws Exception {
        when(limitRepository.findAllByUserId(userId)).thenReturn(null);

        mockMvc.perform(post("/org/example/{userId}/rollbackLimit", userId)
                        .param("amount", String.valueOf(1000)))
                .andExpect(status().isInternalServerError())
                .andExpect(jsonPath("$.statusCode", equalTo(HttpStatus.INTERNAL_SERVER_ERROR.value())))
                .andExpect(jsonPath("$.description")
                        .value("Что-то пошло не так, операция не возможна, повторите попытку еще раз"))
                .andDo(print());
        // проверяем, что метод save был вызван
        verify(limitRepository, times(0)).save(any(Limits.class));
    }

    @Test
    @Sql(statements = "update limits set balance = 10000 where user_id = 1", executionPhase = Sql.ExecutionPhase.AFTER_TEST_METHOD)
    public void testRollbackBalanceByUserId_ok() throws Exception {
        mockMvc.perform(post("/org/example/{userId}/rollbackLimit", userId)
                        .param("amount", String.valueOf(1000))
                        .contentType(APPLICATION_JSON_UTF8_VALUE))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.balance", equalTo(11000)))
                .andDo(print()).andReturn();
    }
}