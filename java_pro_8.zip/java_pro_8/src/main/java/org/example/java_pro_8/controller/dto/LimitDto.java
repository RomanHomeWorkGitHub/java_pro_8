package org.example.java_pro_8.controller.dto;

import lombok.*;
import lombok.experimental.FieldDefaults;
import org.example.java_pro_8.model.Limits;

import java.math.BigDecimal;

@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
public class LimitDto {
    long id;
    BigDecimal balance;
    long userId;

    public LimitDto(Limits limits) {
        this.id = limits.getId();
        this.balance = limits.getBalance();
        this.userId = limits.getUserId();
    }
}
