package org.example.java_pro_8.dao;

import org.example.java_pro_8.model.Limits;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.jdbc.Sql;

import java.math.BigDecimal;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
class LimitRepositoryTest {

    @Autowired
    LimitRepository limitRepository;

    @Test
    void findAllByOrderByIdLimits() {
        List<Limits> limitsExpected = limitRepository.findAllByOrderById();
        assertEquals(100, limitsExpected.size());
        assertEquals(1L, limitsExpected.get(0).getId());
        assertEquals(0, new BigDecimal(10000).compareTo(limitsExpected.get(0).getBalance()));
        assertEquals(1L, limitsExpected.get(0).getUserId());
    }

    @Test
    void findAllByOrderByIdDescByUserId() {
        BigDecimal balanceExpected = limitRepository.findAllByUserId(1L).getBalance();
        assertEquals(0, new BigDecimal(10000).compareTo(balanceExpected));
    }

    @Test
    void existsByUserId() {
        boolean expected = limitRepository.existsByUserId(1L);
        assertTrue(expected);
    }

    @Test
    @Sql(statements = "delete from limits where user_id = 111", executionPhase = Sql.ExecutionPhase.AFTER_TEST_METHOD)
    void save() {
        Limits limits = new Limits(111L, new BigDecimal(100000), 111L);
        limitRepository.save(limits);
        Limits limitsExpected = limitRepository.findAllByUserId(111L);
        assertEquals(111L, limitsExpected.getId());
        assertEquals(0, new BigDecimal(100000).compareTo(limitsExpected.getBalance()));
        assertEquals(111L, limitsExpected.getUserId());
    }
}